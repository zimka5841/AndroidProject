package com.example.myapp

class AuthorizationActivity {

}