package com.example.myapp

class RegistrationActivity {
}